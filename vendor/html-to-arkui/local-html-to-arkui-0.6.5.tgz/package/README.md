# HTML / Screen IR to ArkTS platform core

一个通用、无状态、确定性的静态 HTML / Screen IR → ArkTS 转换包，适合在
Node.js 18+、Agent 和 CI 环境中使用。

本包只实现平台转换能力：解析受限静态 HTML、生成标准 Screen IR、校验组件树、
渲染 ArkTS、收集资源引用和输出诊断。它不依赖 UIBench、Pixso、Tailwind、Lucide
或任何业务页面协议，也不会执行脚本、访问网络或写入文件系统。

## 平台边界

本包负责：

- 通用固定画布 HTML/CSS 解析。
- 标准 Screen IR 与 ArkUI 组件契约。
- Screen IR 结构校验。
- Screen IR → 单文件 ArkTS。
- diagnostics、quality、资源 manifest 和绑定资源返回。
- 相同版本、输入和 options 下的确定性输出。

宿主或适配器负责：

- 在浏览器中执行 Tailwind、Token CSS、图标脚本和媒体查询。
- 把浏览器 computed style、bbox 或业务组件标注整理成标准 Screen IR。
- 下载、授权、复制和改写图片/字体资源。
- 创建 HarmonyOS 工程、路由、权限、签名和构建配置。
- 业务状态、事件、导航和数据绑定。

核心代码中不应出现某个生成器、CSS 框架、业务角色或页面类型的特殊判断。

## 结构化转换 API

```ts
import { convertHtmlToArkUi } from '@local/html-to-arkui';

const result = convertHtmlToArkUi(`
  <!doctype html>
  <html>
    <head>
      <style>
        .frame {
          display: flex;
          flex-direction: column;
          width: 390px;
          height: 844px;
          background: #f5f7fa;
        }
      </style>
    </head>
    <body>
      <main class="frame"><h1>Morning overview</h1></main>
    </body>
  </html>
`, {
  pageName: 'OverviewPage',
  includeSourceMetadata: true,
});

console.log(result.screenIr);
console.log(result.arkTs);
console.log(result.diagnostics);
console.log(result.quality.readiness);
```

结构化结果包含：

- `screenIr`：标准 ArkUI Screen IR。
- `arkTs`：完整单文件 ArkTS 页面源码。
- `viewport`：最终画布和来源。
- `assets` / `assetFiles`：资源清单与调用方提供的已绑定资源。
- `diagnostics`：确定性排序的能力损失和错误。
- `quality`：`ready / lossy / blocked`、诊断计数和组件计数。
- `confidence` / `stats`：兼容现有转换统计的启发式指标。

`quality.readiness === 'blocked'` 表示存在 error diagnostics，不应直接进入正式导出。
`confidence` 只是辅助数据，不应单独作为生产就绪判断。

## Screen IR API

HTML 适配器不是使用本包的必要条件。任何系统都可以直接生产标准 Screen IR：

```ts
import {
  getArkUiComponentDefinitions,
  renderScreenIrToArkTs,
  validateScreenIr,
  type ScreenIr,
} from '@local/html-to-arkui';

const screen: ScreenIr = {
  schemaVersion: 2,
  page: { name: 'HelloPage' },
  ui: {
    componentName: 'Column',
    meta: { nodeId: 'root' },
    children: [{
      componentName: 'Text',
      content: 'Hello',
      meta: { nodeId: 'title' },
    }],
  },
};

const validation = validateScreenIr(screen);
if (!validation.valid) throw new Error(JSON.stringify(validation.issues));

console.log(renderScreenIrToArkTs(screen));
console.log(getArkUiComponentDefinitions());
```

当前 Renderer 实现的组件为 `Row`、`Column`、`Stack`、`Scroll`、`Text`、`Span`、
`Image`、`SymbolGlyph`、`Divider`、`Button`、`List`、`ListItem`、`Grid` 和
`GridItem`。
组件注册表只声明已经可以渲染的能力，后续组件应先实现约束和测试，再加入注册表。

跨语言调用应使用包内两个版本化契约：

- `contracts/screen-ir.schema.json`
- `contracts/arkui-component-registry.json`

当前标准契约是 Screen IR v2，只接受 `meta.nodeId`。运行时校验器和 Renderer 仍可读取
Screen IR v1 的 `meta.octoId` 或缺失 metadata，并返回迁移 warning；新生产者必须输出 v2。

`Divider` 的线条外观使用专用、平台无关的 style 字段表达：`dividerColor`、
`dividerStrokeWidth` 和 `dividerVertical`。这些字段只允许出现在 `Divider` 节点，Renderer
分别生成 ArkUI 的 `.color(...)`、`.strokeWidth(...)` 和 `.vertical(...)` 修饰器。

`List` 只接受 `ListItem` 子节点，`ListItem` 只能出现在 `List` 内且最多包含一个子节点，
两者都不能作为页面根节点之外的任意位置随意出现。`List` 与 `Row`、`Column` 一样支持
`space` 表达子项间距，Renderer 生成 `List({ space: N })`，间距始终沿 List 主轴分布。
ArkUI 的 `List` 默认纵向排列，因此横向列表必须显式声明 `listDirection`（`Horizontal`
或 `Vertical`），Renderer 生成 `.listDirection(Axis.Horizontal)`；该字段只允许出现在
`List` 节点。`List` 和 `ListItem` 目前只能
通过 Screen IR 生产，HTML lowering 不会自动产生它们；与 `Scroll`、`SymbolGlyph` 相同，
宿主需要根据自身的业务标注决定何时使用集合组件。

`Grid` 只接受 `GridItem` 子节点，`GridItem` 只能出现在 `Grid` 内且最多包含一个
子节点。轨道用 `columnsTemplate` / `rowsTemplate` 表达，只接受 `"1fr 2fr"` 这类
fr/vp/px/% 的空格分隔轨道表（`repeat()`、`auto-fill` 等关键字不可表达），间距用
`columnsGap` / `rowsGap`；四个字段只允许出现在 `Grid` 节点，Renderer 生成
`.columnsTemplate("1fr 2fr")` 等修饰器。与 `List` 相同，Grid 只能通过 Screen IR
生产，HTML lowering 不会自动产生它们。

文本度量与边框有精确的原生形式：`letterSpacing`（`Text` / `Span`）、`maxLines` 与
`textOverflow: "Ellipsis"`（仅 `Text`）分别生成 `.letterSpacing(n)`、`.maxLines(n)`
和 `.textOverflow({ overflow: TextOverflow.Ellipsis })`；`minHeight` 接受 vp 数值或
`'100%'` 一类百分比字符串，其余字符串（如 `'auto'`）会被 Screen IR 校验与 Renderer
一并拒绝；它生成 `.constraintSize({ minHeight: ... })`，其下限在
`Scroll` 的无限主轴约束内依然生效。`border` 的 `width` / `color` / `style` 除统一
标量外还接受按 `top` / `right` / `bottom` / `left` 分边的对象，对应 ArkUI 的
`EdgeWidths` / `EdgeColors` / `EdgeStyles`；空的分边对象按「未指定」处理，落到
ArkUI 默认值（黑色 / Solid），不会使整条边框消失。

Node.js 调用方可以通过包子路径定位两个契约，例如
`@local/html-to-arkui/contracts/screen-ir.schema.json`。

## 兼容字符串 API

原有 API 保持兼容：

```ts
import { htmlToArkTs } from '@local/html-to-arkui';

const arkTs = htmlToArkTs('<p>Hello</p>');
```

它等价于：

```ts
convertHtmlToArkUi('<p>Hello</p>').arkTs
```

## 固定画布与 viewport

转换器面向固定画布静态 HTML，而不是完整响应式网站。可以显式传入 viewport：

```ts
convertHtmlToArkUi(html, { viewport: { width: 390, height: 844 } });
```

未传入时，转换器从 `<meta name="viewport">` 或顶层明确像素宽高推断；无法可靠
推断时使用 `390 × 844`。它不会读取操作系统屏幕、浏览器窗口或环境变量。

媒体查询、百分比 used value、字体 shaping、自动换行高度和 intrinsic sizing 需要由
宿主的浏览器固化层处理后再转换成 Screen IR。

## HTML/CSS 能力范围

当前静态 HTML lowering 主要覆盖：

| HTML/CSS | Screen IR / ArkTS |
|---|---|
| 可见文本、标题、段落、简单 span | `Text` |
| `img` | `Image` |
| `button` | `Button` |
| `hr` | `Divider` |
| 单行 flex row/column | `Row` / `Column` |
| 普通文档流容器 | `Column` |
| 明确的绝对定位和重叠层 | `Stack` 与位置修饰器 |
| width/height/gap/padding/margin | 对应尺寸与间距 |
| justify-content/align-items | ArkUI 对齐枚举 |
| 常见颜色、字号、字重、字体、行高 | 对应 ArkUI 样式 |
| 背景色、单背景图、linear-gradient、圆角、边框、透明度 | 对应容器样式 |
| object-fit | `Image.objectFit` |

支持的 selector 子集包括 universal、tag、class、id、compound、逗号列表、descendant
和 direct child；级联处理 `!important`、specificity、source order、inline style 和部分
文字属性继承。

当前不会完整还原 flex-wrap、复杂 Grid、媒体查询、伪类/伪元素、attribute selector、
sibling combinator、`margin:auto`、滚动容器、富文本局部样式、SVG、canvas、mask 和
复杂滤镜。无法准确迁移的能力会进入 diagnostics，而不是静默伪装成完整支持。

## 浏览器和外部样式

核心不会启动 Chromium、Playwright 或其他浏览器，也不会执行 `<script>` 或抓取
`<link rel="stylesheet">`。需要 Tailwind、CSS 变量、媒体查询、Lucide 或真实 used
values 时，应在宿主侧先完成浏览器固化，再把结果转换成标准 Screen IR。

这条边界保证核心没有网络副作用、运行环境小且输出可复现，也避免在本包中重新实现
完整浏览器排版引擎。

## 图片与字体资源

核心不会下载或写入资源，也不会生成虚假的 `$r('app.media.*')`。字符串输入中的本地
URL 会保留并产生待物化诊断注释；bundle 输入可以携带 `Uint8Array`，对应文件通过
`assetFiles` 返回给宿主处理。

完整 HarmonyOS 工程仍需宿主完成资源目录写入、`$r(...)` 改写、字体注册、网络权限、
路由、签名和构建。

## 输入复杂度边界

- 最多遍历 `10000` 个 element/text 节点。
- 最多转换 `256` 层。
- 可渲染绝对数值长度的绝对值不超过 `1000000000`。
- Screen IR 校验同样采用显式栈，并限制为 `10000` 个节点和 `256` 层。

达到限制时会产生稳定诊断；这不是完整的进程沙箱，调用方仍应限制原始输入字节数、
执行时间和进程资源。

## 开发与打包

```bash
npm install
npm run typecheck
npm test
npm run build
npm run verify
npm pack
```

构建会从 TypeScript 源码生成 JavaScript、source map 和声明文件，避免手工维护公开类型
造成漂移。运行时依赖只有纯 JavaScript HTML/CSS AST 解析库；包边界检查禁止引入
浏览器自动化、原生布局引擎或宿主项目代码。
